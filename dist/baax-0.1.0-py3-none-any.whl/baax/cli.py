import click

@click.command()
def main():
    click.echo("Welcome to Baax! Let's bootstrap your backend.")

if __name__ == "__main__":
    main()
